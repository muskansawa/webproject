from flask import Flask, render_template, redirect, session, url_for, request
from flask_mysqldb import MySQL
import MySQLdb
import re

app = Flask(__name__)
app.secret_key = "12345"

app.config["MYSQL_HOST"] = "localhost"
app.config["MYSQL_USER"] = "root"
app.config["MYSQL_PASSWORD"] = "root"
app.config["MYSQL_db1"] = "teams"

db1 = MySQL(app)

@app.route('/', methods=["GET", "POST"])
def profile():
    msg = ''
    List = [
        ['1','Rhino Hurricanes','Uttar Pradesh','blue'],
        ['2','Midnight Stars','J&K','blue'],
        ['3','Rocky Assassins','Delhi','blue'],
        ['4','Striking Sharpshooters','Delhi','red'],
        ['5','Skull Fireballs','Goa','blue'],
        ['6','Blue Bombers','Haryana','red'],
        ['7','Blue Geckos','Madhya Pradesh','red'],
        ['8','Midnight Miners','Uttar Pradesh','red'],
        ['9','Spirit Blockers','Andra Pradesh','blue'],
        ['10','Wind Kamikaze Pilots','Kerala','blue'],
        ['11','Retro Chuckers','Uttarakhand','blue'],
        ['12','Venomous Cyborgs','West Bengal','blue'],
        ['13','Quicksilver Ninjas','Sikkim','blue'],
        ['14','Alpha Blockers','Rajasthan','red'],
        ['15','Retro Heroes','Haryana','blue'],
        ['16','Lions','Punjab','blue'],
        ['17','Raging Spanners','Himachal Pradesh','blue'],
        ['18','Poison Spiders','Odisha','red'],
        ['19','Black Bullets','Uttar Pradesh','blue'],
        ['20', 'Thunder Commandos','Uttar Pradesh','blue'],
        ['21','Venomous Sharks','Haryana','blue'],
        ['22','Killer Stars','Nagaland','blue'],
        ['23','Tornado Geckos','Punjab','red'],
        ['24','Knockout Busters','Madhya Pradesh','blue'],
        ['25','Muffin Racers','Maharashtra','red'],
        ['26','Real Madrid','Delhi','blue'],
        ['27','Demolition Piledrivers','Rajasthan','blue'],
        ['28',' Flying Xpress','Delhi','blue'],
        ['29','Silver Wasps','Uttarakhand','blue'],
        ['30','The Showstoppers','Delhi','blue'],
        ['31','Wolfsburg','Haryana','blue'],
        ['32','Black & White Gangstaz','Andra Pradesh','red']
    ]

    dict = {'A':[],'B':[],'C':[],'D':[],'E':[],'F':[],'G':[],'H':[]}

    def check_name(name):
        for x in dict.values():
            for y in x:
                if y == name:
                    return False
        return True

    def fetch_state(name):
        for x in List:
            if x[1] == name: return x[2]


    def check_state(group,state):
        for x in dict[group]:
            for y in x:
                if fetch_state(y) == state:
                    return False
        return True

    for x in dict.keys():
        for team in List:
            if team[3] == "red" and check_name(team[1]):
                dict[x].append(team[1])
                break

    for x in dict.keys():
        for team in List:
            if len(dict[x]) < 4 and check_name(team[1]) and check_state(x,team[2]):
                dict[x].append(team[1])

    length_dict = len(dict)

    # if request.method == 'POST':
    #      cursor = db1.connection.cursor(MySQLdb.cursors.DictCursor)
    #      for x in dict:
    #          sql = "INSERT INTO groups (group_name, member1, member2, member3, member4) VALUES(%s, %s, %s, %s, %s)"
    #          values = (str(x), str(dict[x][0]), str(dict[x][1]), str(dict[x][2]), str(dict[x][3]))
    #          cursor.execute(sql, values)
    #      db1.connection.commit()
    #      cursor.close()
    #      msg = 'Logged in successfully !'
    #      return render_template("profile.html", dict = dict, length_dict = length_dict, msg = msg)
    return render_template("profile.html", dict = dict, length_dict = length_dict, msg = msg)

if __name__ == '__main__':
    app.run(debug=True)
