requirements :

pip install mysqlclient
Pip install flask
Pip install flask-mysqldb

---------------------------
to start:

1> activate the virtual env
2> run: main:py
3>go to localhost:5000